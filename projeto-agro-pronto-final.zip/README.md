# Sistema de Apoio à Irrigação no Agronegócio

## Sobre o projeto

Este projeto foi desenvolvido com o objetivo de simular um sistema simples de apoio à decisão no agronegócio, focado principalmente no controle de irrigação de plantações.

A ideia é ajudar na decisão de irrigar ou não com base em dados simples do solo.

## Como funciona

O usuário informa:
- cultura
- área
- umidade
- pH
- previsão de chuva

E o sistema retorna uma recomendação de irrigação.

## Regras

- Se vai chover → não irrigar
- Se umidade < 55% e pH ok → irrigar
- Se pH ruim → corrigir antes

## Tecnologias usadas

- Python
- Funções
- Lista e dicionário
- Tupla
- JSON para salvar dados

## Como rodar

```bash
python main.py
```

## Autor

Projeto desenvolvido por [SEU NOME AQUI]
