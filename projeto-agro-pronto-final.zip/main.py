# Projeto simples de apoio à irrigação
# Desenvolvido para disciplina de IA / Python

import json
import os

ARQUIVO = "dados.json"

def carregar():
    if not os.path.exists(ARQUIVO):
        return []
    with open(ARQUIVO, "r", encoding="utf-8") as f:
        return json.load(f)

def salvar(dados):
    with open(ARQUIVO, "w", encoding="utf-8") as f:
        json.dump(dados, f, indent=4, ensure_ascii=False)

def decidir_irrigacao(umidade, ph, chuva):
    if chuva == "S":
        return "Não irrigar (vai chover)"
    if umidade < 55 and 5.5 <= ph <= 7:
        return "Ligar irrigação"
    if umidade < 55:
        return "Corrigir pH antes de irrigar"
    return "Não irrigar"

def cadastrar(dados):
    print("\n--- Cadastro ---")
    nome = input("Cultura: ")
    area = float(input("Área (ha): "))
    umidade = float(input("Umidade (%): "))
    ph = float(input("pH (0 a 14): "))
    chuva = input("Vai chover? (S/N): ").upper()

    decisao = decidir_irrigacao(umidade, ph, chuva)

    registro = {
        "nome": nome,
        "area": area,
        "umidade": umidade,
        "ph": ph,
        "chuva": chuva,
        "decisao": decisao
    }

    dados.append(registro)
    salvar(dados)

    print("Decisão:", decisao)

def listar(dados):
    print("\n--- Lista ---")
    for i, d in enumerate(dados):
        print(i+1, d)

def relatorio(dados):
    if not dados:
        print("Sem dados")
        return

    media = sum(d["umidade"] for d in dados) / len(dados)
    culturas = tuple(set(d["nome"] for d in dados))

    print("\n--- Relatório ---")
    print("Média de umidade:", media)
    print("Culturas:", culturas)

def menu():
    dados = carregar()

    while True:
        print("\n1-Cadastrar 2-Listar 3-Relatório 4-Sair")
        op = input("Escolha: ")

        if op == "1":
            cadastrar(dados)
        elif op == "2":
            listar(dados)
        elif op == "3":
            relatorio(dados)
        elif op == "4":
            break
        else:
            print("Opção inválida")

menu()
